package io.pivotal.cloudnativespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudNativeSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
