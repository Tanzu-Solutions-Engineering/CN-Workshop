package io.pivotal.cloudnativespringui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudNativeSpringUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
